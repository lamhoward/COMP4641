# COMP4641
# Assignment 2

* Name: Lam Hon Wa
* Student ID: 20348745
* Email: hwlamad@connect.ust.hk

## Python 3.0
Please be reminded the code is written in python version 3.0

## file struction

* folder
	- Q1.ipynb
	- A2_report.pdf
	- README.md



## Q1.ipynb
This script is the codes for question 1 . Just run the code and get the results.


